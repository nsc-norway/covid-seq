# util

NC_045512.2.fasta Genome for SARS-COV2

sarscov2_v2_masterfile.txt from Swfit
swift_primers.py produces swift_primers.bed from sarscov2_v2_masterfile.txt
swift_primers.py produces swift_primers.fasta from sarscov2_v2_masterfile.txt

nimagen_masterfile.txt from NimaGen
nimagen_primers.bed from NimaGen
nimagen_amplicons.bed from NimaGen
